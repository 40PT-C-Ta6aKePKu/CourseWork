﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Coursework
{
    public partial class MainAppForm : Form
    {
        private LoginForm loginForm;
        private string tableName;
        private SqlDataAdapter da;
        private DataTable dt;
        private string username;
        private string accessRights;
        public MainAppForm(string username, string accessRights)
        {
            InitializeComponent();
            this.username = username;
            this.accessRights = accessRights;

            // Определяем права доступа и скрываем/отображаем элементы управления
            SetAccessRights();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\CourseWork\Coursework\Coursework\Database1.mdf;Integrated Security=True");

        private void SetAccessRights()
        {
            if (accessRights == "Full")
            {
                // Для администратора отображаем все элементы управления

                // Включаем кнопку удаления записи
                btnDelete.Visible = true;

                // Включаем кнопку сохранения изменений
                btnSaveChanges.Enabled = true;

                // Отображаем кнопку добавления данных
                btnAdd.Enabled = true;
            }
            else if (accessRights == "Partial")
            {
                // Для обычного пользователя скрываем определенные элементы управления

                // Отключаем кнопку удаления записи
                btnDelete.Visible = false;

                // Отключаем кнопку сохранения изменений
                btnSaveChanges.Enabled = true;

                // Скрываем кнопку добавления данных
                btnAdd.Enabled = true;
            }
        }
        private void checkedListBox_DB_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Если пользователь пытается выбрать элемент
            if (e.NewValue == CheckState.Checked)
            {
                // Снимаем выделение со всех других элементов
                for (int ix = 0; ix < checkedListBox_DB.Items.Count; ++ix)
                {
                    if (ix != e.Index)
                    {
                        checkedListBox_DB.SetItemChecked(ix, false);
                    }
                }

                string selectedTable = checkedListBox_DB.Items[e.Index].ToString();
                ShowTable(selectedTable);
                LoadColumns(selectedTable);
            }
        }

        private void ShowTable(string tableName)
        {
            try
            {
                con.Open();
                // Выполняем запрос к базе данных
                string query = "SELECT * FROM " + tableName;
                SqlCommand cmd = new SqlCommand(query, con);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);

                // Отображаем результаты в dataGridView
                dataGridView1.DataSource = dt;
                this.tableName = tableName;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Проверяем, выбран ли какой-либо элемент в checkedListBox
            if (checkedListBox_DB.CheckedItems.Count > 0)
            {
                // Получаем выбранный элемент
                string selectedTable = checkedListBox_DB.CheckedItems[0].ToString();

                // Открываем форму для ввода данных
                AddDataForm addDataForm = new AddDataForm(selectedTable);
                addDataForm.ShowDialog();

                // Обновляем dataGridView после добавления данных
                ShowTable(selectedTable);
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите таблицу для добавления данных.");
            }
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Проверяем, выбрана ли какая-либо запись в dataGridView
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Получаем значение первой ячейки выбранной строки (обычно это первичный ключ)
                string primaryKeyValue = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

                // Удаляем запись из таблицы
                DeleteRecord(this.tableName, primaryKeyValue);

                // Обновляем dataGridView после удаления записи
                ShowTable(tableName);
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.");
            }
        }
        private void DeleteRecord(string tableName, string primaryKeyValue)
        {
            try
            {
                con.Open();
                // Получаем имя первичного ключа для текущей таблицы
                SqlCommand cmdPrimaryKey = new SqlCommand($"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_NAME = '{tableName}'", con);
                string primaryKeyColumnName = (string)cmdPrimaryKey.ExecuteScalar();

                // Строим запрос для удаления записи
                string query = $"DELETE FROM {tableName} WHERE {primaryKeyColumnName} = @PrimaryKeyValue";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@PrimaryKeyValue", primaryKeyValue);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Запись успешно удалена из таблицы " + tableName);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            try
            {
                // Подготавливаем команду для обновления данных
                SqlCommandBuilder cmdBuilder = new SqlCommandBuilder(da);
                da.Update(dt);

                MessageBox.Show("Изменения успешно сохранены.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении изменений: " + ex.Message);
            }
        }


        private void LoadColumns(string tableName)
        {
            try
            {
                con.Open();
                // Получаем список столбцов выбранной таблицы
                DataTable schemaTable = con.GetSchema("Columns");
                comboBox_Column.Items.Clear();

                foreach (DataRow row in schemaTable.Rows)
                {
                    if (row["TABLE_NAME"].ToString() == tableName)
                    {
                        comboBox_Column.Items.Add(row["COLUMN_NAME"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox_Search.Text) && comboBox_Column.SelectedItem != null)
            {
                string searchColumn = comboBox_Column.SelectedItem.ToString();
                string searchText = textBox_Search.Text;

                try
                {
                    con.Open();
                    // Формируем SQL-запрос с использованием параметров
                    string query = $"SELECT * FROM {tableName} WHERE {searchColumn} LIKE @SearchText";
                    SqlCommand cmd = new SqlCommand(query, con);
                    // Добавляем параметр для поиска текста с учетом Unicode
                    cmd.Parameters.AddWithValue("@SearchText", $"%{searchText}%");
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Создаем новую DataTable для хранения результатов
                    DataTable searchResults = new DataTable();
                    searchResults.Load(reader);

                    // Отображаем результаты в dataGridView
                    dataGridView1.DataSource = searchResults;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите текст для поиска и выберите столбец.");
            }
        }

        private void RefreshData()
        {
            try
            {
                con.Open();
                // Выполняем запрос к базе данных без условий поиска
                string query = $"SELECT * FROM {tableName}";
                SqlCommand cmd = new SqlCommand(query, con);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);

                // Отображаем результаты в dataGridView
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void btnRefreshData_Click(object sender, EventArgs e)
        {
            RefreshData();
        }
    }
}

