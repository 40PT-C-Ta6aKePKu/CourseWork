﻿namespace Coursework
{
    partial class MainAppForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainAppForm));
            dataGridView1 = new DataGridView();
            mainAppFormBindingSource = new BindingSource(components);
            btnAdd = new Button();
            btnDelete = new Button();
            checkedListBox_DB = new CheckedListBox();
            label1 = new Label();
            label2 = new Label();
            btnLogout = new Button();
            btnSaveChanges = new Button();
            comboBox_Column = new ComboBox();
            textBox_Search = new TextBox();
            btnSearch = new Button();
            label3 = new Label();
            btnRefreshData = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)mainAppFormBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(dataGridView1, "dataGridView1");
            dataGridView1.Name = "dataGridView1";
            // 
            // mainAppFormBindingSource
            // 
            mainAppFormBindingSource.DataSource = typeof(MainAppForm);
            // 
            // btnAdd
            // 
            resources.ApplyResources(btnAdd, "btnAdd");
            btnAdd.Name = "btnAdd";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDelete
            // 
            resources.ApplyResources(btnDelete, "btnDelete");
            btnDelete.Name = "btnDelete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // checkedListBox_DB
            // 
            checkedListBox_DB.BackColor = SystemColors.Control;
            checkedListBox_DB.CheckOnClick = true;
            checkedListBox_DB.FormattingEnabled = true;
            checkedListBox_DB.Items.AddRange(new object[] { resources.GetString("checkedListBox_DB.Items"), resources.GetString("checkedListBox_DB.Items1"), resources.GetString("checkedListBox_DB.Items2"), resources.GetString("checkedListBox_DB.Items3") });
            resources.ApplyResources(checkedListBox_DB, "checkedListBox_DB");
            checkedListBox_DB.Name = "checkedListBox_DB";
            checkedListBox_DB.ItemCheck += checkedListBox_DB_ItemCheck;
            // 
            // label1
            // 
            resources.ApplyResources(label1, "label1");
            label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(label2, "label2");
            label2.Name = "label2";
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.Red;
            resources.ApplyResources(btnLogout, "btnLogout");
            btnLogout.ForeColor = SystemColors.InfoText;
            btnLogout.Name = "btnLogout";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += btnLogout_Click;
            // 
            // btnSaveChanges
            // 
            resources.ApplyResources(btnSaveChanges, "btnSaveChanges");
            btnSaveChanges.Name = "btnSaveChanges";
            btnSaveChanges.UseVisualStyleBackColor = true;
            btnSaveChanges.Click += btnSaveChanges_Click;
            // 
            // comboBox_Column
            // 
            resources.ApplyResources(comboBox_Column, "comboBox_Column");
            comboBox_Column.FormattingEnabled = true;
            comboBox_Column.Name = "comboBox_Column";
            // 
            // textBox_Search
            // 
            resources.ApplyResources(textBox_Search, "textBox_Search");
            textBox_Search.Name = "textBox_Search";
            // 
            // btnSearch
            // 
            resources.ApplyResources(btnSearch, "btnSearch");
            btnSearch.Name = "btnSearch";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // label3
            // 
            resources.ApplyResources(label3, "label3");
            label3.Name = "label3";
            // 
            // btnRefreshData
            // 
            resources.ApplyResources(btnRefreshData, "btnRefreshData");
            btnRefreshData.Name = "btnRefreshData";
            btnRefreshData.UseVisualStyleBackColor = true;
            btnRefreshData.Click += btnRefreshData_Click;
            // 
            // MainAppForm
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Font;
            ControlBox = false;
            Controls.Add(btnRefreshData);
            Controls.Add(label3);
            Controls.Add(btnSearch);
            Controls.Add(textBox_Search);
            Controls.Add(comboBox_Column);
            Controls.Add(btnSaveChanges);
            Controls.Add(btnLogout);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(checkedListBox_DB);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Name = "MainAppForm";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)mainAppFormBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private BindingSource mainAppFormBindingSource;
        private Button btnAdd;
        private Button btnDelete;
        private CheckedListBox checkedListBox_DB;
        private Label label1;
        private Label label2;
        private Button btnLogout;
        private Button btnSaveChanges;
        private ComboBox comboBox_Column;
        private TextBox textBox_Search;
        private Button btnSearch;
        private Label label3;
        private Button btnRefreshData;
    }
}