﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Coursework
{
    public partial class AddDataForm : Form
    {
        private string tableName;
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\CourseWork\Coursework\Coursework\Database1.mdf;Integrated Security=True");
        public AddDataForm(string tableName)
        {
            InitializeComponent();
            this.tableName = tableName;
            PopulateControls();
        }

        private void PopulateControls()
        {
            try
            {
                con.Open();
                string query = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" + tableName + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                int y = 10;
                while (reader.Read())
                {
                    string columnName = reader.GetString(0);
                    System.Windows.Forms.Label label = new System.Windows.Forms.Label();
                    label.Text = columnName + ":";
                    label.AutoSize = true;
                    label.Location = new Point(10, y);

                    System.Windows.Forms.TextBox textBox = new System.Windows.Forms.TextBox();
                    textBox.Name = "textBox_" + columnName;
                    textBox.Location = new Point(120, y);
                    textBox.Width = 200;

                    Controls.Add(label);
                    Controls.Add(textBox);

                    y += 30;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void btnAddData_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                // Создаем строку для столбцов и значения параметров
                StringBuilder columns = new StringBuilder();
                StringBuilder values = new StringBuilder();
                List<SqlParameter> parameters = new List<SqlParameter>();

                foreach (Control control in Controls)
                {
                    if (control is System.Windows.Forms.TextBox textBox)
                    {
                        string columnName = textBox.Name.Replace("textBox_", "");

                        // Добавляем имя столбца в строку столбцов
                        columns.Append(columnName).Append(",");

                        // Добавляем параметр в список параметров
                        parameters.Add(new SqlParameter("@" + columnName, SqlDbType.NVarChar) { Value = textBox.Text });

                        // Добавляем параметр в строку значений
                        values.Append("@").Append(columnName).Append(",");
                    }
                }

                // Удаляем последнюю запятую из строк
                columns.Remove(columns.Length - 1, 1);
                values.Remove(values.Length - 1, 1);

                // Формируем SQL-запрос с параметрами
                string query = $"INSERT INTO {tableName} ({columns}) VALUES ({values})";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddRange(parameters.ToArray());
                cmd.ExecuteNonQuery();

                MessageBox.Show($"Дані успішно додані до таблиці {tableName}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}");
            }
            finally
            {
                con.Close();
                this.Close(); // Закрываем форму после добавления данных
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
