using Microsoft.VisualBasic.ApplicationServices;
using System.Data.SqlClient;

namespace Coursework
{
    public partial class LoginForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\CourseWork\Coursework\Coursework\Database1.mdf;Integrated Security=True");
        public LoginForm()
        {
            InitializeComponent();
        }


        private void btnLog_Click(object sender, EventArgs e)
        {
            string username = Login.Text;
            string password = Password.Text;

            try
            {
                using (SqlConnection connection = new SqlConnection(con.ConnectionString))
                {
                    string query = "SELECT Username, AccessRights FROM Users WHERE Username = @Username AND Password = @Password";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        string user = reader["Username"].ToString();
                        string accessRights = reader["AccessRights"].ToString();

                        MainAppForm mainForm = new MainAppForm(user, accessRights);
                        mainForm.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("�������� ��� ������������ ��� ������!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("������ ��� ��������������: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            {
                // ������� ���� ������ � ������
                Login.Text = "";
                Password.Text = "";
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
