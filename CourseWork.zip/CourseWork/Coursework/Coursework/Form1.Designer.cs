﻿namespace Coursework
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            btnLog = new Button();
            btnClear = new Button();
            Login = new TextBox();
            Password = new TextBox();
            btnExit = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btnLog
            // 
            resources.ApplyResources(btnLog, "btnLog");
            btnLog.Name = "btnLog";
            btnLog.UseVisualStyleBackColor = true;
            btnLog.Click += btnLog_Click;
            // 
            // btnClear
            // 
            resources.ApplyResources(btnClear, "btnClear");
            btnClear.Name = "btnClear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // Login
            // 
            resources.ApplyResources(Login, "Login");
            Login.Name = "Login";
            // 
            // Password
            // 
            resources.ApplyResources(Password, "Password");
            Password.Name = "Password";
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Red;
            resources.ApplyResources(btnExit, "btnExit");
            btnExit.ForeColor = SystemColors.InfoText;
            btnExit.Name = "btnExit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // label1
            // 
            resources.ApplyResources(label1, "label1");
            label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(label2, "label2");
            label2.Name = "label2";
            // 
            // LoginForm
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Font;
            ControlBox = false;
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnExit);
            Controls.Add(Password);
            Controls.Add(Login);
            Controls.Add(btnClear);
            Controls.Add(btnLog);
            Name = "LoginForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnLog;
        private Button btnClear;
        private TextBox Login;
        private TextBox Password;
        private Button btnExit;
        private Label label1;
        private Label label2;
    }
}
