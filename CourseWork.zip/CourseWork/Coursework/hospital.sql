﻿CREATE TABLE [dbo].[Users]
(
	[Username] TEXT NOT NULL PRIMARY KEY, 
    [Password] TEXT NOT NULL
)
